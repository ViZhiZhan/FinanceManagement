package com.example.user.financemanagement;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;

import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;

public class HistoryActivity extends AppCompatActivity {

    String color,year,month1,month2;
    int LAUNCH_SECOND_ACTIVITY = 1;
    CardView cvList,cvChart,cvSummary;

    FrameLayout f1;
    ConstraintLayout c1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        f1 = (FrameLayout) findViewById(R.id.container);
        c1= (ConstraintLayout) findViewById(R.id.container1);
        cvList = (CardView) findViewById(R.id.cvList);
        cvChart = (CardView) findViewById(R.id.cvChart);
        cvSummary = (CardView) findViewById(R.id.cvSummary);


        FirebaseDatabase database = FirebaseDatabase.getInstance();

        final DatabaseReference myRef = database.getReference().child("Background");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot data:dataSnapshot.getChildren()) {
                    color=data.child("code").getValue(String.class);
                    f1.setBackgroundColor(Color.parseColor(color));
                    c1.setBackgroundColor(Color.parseColor(color));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        cvList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HistoryActivity.this,HistoryListActivity.class);
                startActivityForResult(intent,LAUNCH_SECOND_ACTIVITY);


            }
        });

        cvChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HistoryActivity.this,HistoryChartActivity.class);
                startActivityForResult(intent,LAUNCH_SECOND_ACTIVITY);

            }
        });

        cvSummary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(HistoryActivity.this,HistorySummaryActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivityForResult(intent,LAUNCH_SECOND_ACTIVITY);

            }
        });

    }

}