package com.example.user.financemanagement;

public class Category {
    public String categoryName;

    public Category(String categoryName) {
        this.categoryName = categoryName;
    }
}
