package com.example.user.financemanagement;

public class BackgroundColour {
    public String code;


    public BackgroundColour(){

    }

    public BackgroundColour(String code) {
        this.code = code;
    }

}
