package com.example.user.financemanagement;

public class ExpenseList{

    //Member variables representing the title and information about the sport
    private String title;
    private String amount;

    /**
     * Constructor for the Data data model
     * @param title The title of the data.
     * @param amount amount about the data.
     */
    ExpenseList(String title, String amount) {
        this.title = title;
        this.amount = amount;

    }

    /**
     * Gets the title of the data
     * @return The title of the data.
     */
    String getTitle() {
        return title;
    }
    /**
     * Gets the amount about the data
     * @return The info about the data.
     */
    String getAmount() {
        return amount;
    }
}
