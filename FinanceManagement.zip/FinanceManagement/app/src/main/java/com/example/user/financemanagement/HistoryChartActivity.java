package com.example.user.financemanagement;

import android.content.Intent;
import android.graphics.Color;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class HistoryChartActivity extends AppCompatActivity {

    String color,year,month1,month2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_chart);

        final TabLayout tabLayout=(TabLayout)findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Income"));
        tabLayout.addTab(tabLayout.newTab().setText("Expense"));

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager vp=(ViewPager)findViewById(R.id.viewPager);

        PagerAdapter4 pa =new PagerAdapter4(getSupportFragmentManager(),tabLayout.getTabCount());

        vp.setAdapter(pa);

        vp.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener(){
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vp.setCurrentItem(tab.getPosition());

                if (tab.getPosition() == 0) {
                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#ff99cc00"));

                } else if (tab.getPosition() == 1) {

                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#FF1700"));


                }

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}