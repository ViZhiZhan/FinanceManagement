package com.example.user.financemanagement;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;

import android.os.Bundle;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class FragmentHistoryExpenseActivity extends Fragment {

    private DataAdapter mAdapter;
    private RecyclerView completeRecycle;
    private View complete;
    EditText amout,description;
    TextView tvDate;
    Spinner mSpCategoryIncome,mSpCategoryExpense;
    ArrayList<String> arrCategory,arrCategoryExpense;
    RadioGroup mRgType;
    String type,category;
    int rbId;
    private final LinkedList<String> typeList= new LinkedList<>();
    private final LinkedList<String> amountList= new LinkedList<>();
    private final LinkedList<String> dateList= new LinkedList<>();
    private final LinkedList<String> categoryList=  new LinkedList<>();
    private final LinkedList<String> descriptionList= new LinkedList<>();
    private final LinkedList<String> childName= new LinkedList<>();

    CoordinatorLayout c1;
    String color,year,month1,month2;
    int month=0;

    SharedPreferences prf;
    SwipeController swipeController = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        complete=inflater.inflate(R.layout.activity_fragment_history_expense,container,false);
        completeRecycle=(RecyclerView) complete.findViewById(R.id.expenseView);

        c1= (CoordinatorLayout) complete.findViewById(R.id.expense2) ;

        FirebaseDatabase database2 = FirebaseDatabase.getInstance();

        final DatabaseReference myRef2 = database2.getReference().child("Background");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot data:dataSnapshot.getChildren()) {
                    color=data.child("code").getValue(String.class);

                    c1.setBackgroundColor(Color.parseColor(color));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        // Inflate the layout for this fragment
        return complete;
    }

    @Override
    public void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prf = getContext().getSharedPreferences("history", Context.MODE_PRIVATE);

        year = prf.getString("year",null);
        month1 = prf.getString("month1",null);
        month2 = prf.getString("month2",null);

        month=Integer.parseInt(month1);

        final LinkedList<String> monthlist=new LinkedList<>();
        final LinkedList<String> categorylist2=new LinkedList<>();
        final LinkedList<String> amountlist2=new LinkedList<>();
        final LinkedList<String> typelist2=new LinkedList<>();
        final LinkedList<String> datelist2=new LinkedList<>();
        final LinkedList<String> descriptionlist2=new LinkedList<>();
        final LinkedList<String> childName2= new LinkedList<>();

        FirebaseDatabase database=FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("List").child(year);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()){

                    for (DataSnapshot data1 : data.getChildren()) {

                        for (DataSnapshot ds : data1.getChildren()) {
                            if (ds.child("type").getValue(String.class).equals("Expense")) {

                                monthlist.add(data.getKey());
                                childName2.addLast(ds.getKey());
                                typelist2.addLast(ds.child("type").getValue(String.class));
                                amountlist2.addLast(ds.child("amount").getValue(String.class));
                                datelist2.addLast(ds.child("date").getValue(String.class));
                                categorylist2.addLast(ds.child("category").getValue(String.class));
                                descriptionlist2.addLast(ds.child("description").getValue(String.class));

                            }

                        }

                    }
                }

                for (int i=month; i<=Integer.parseInt(month2);i++){

                    for (int j=0; j<monthlist.size();j++){

                        if (i == Integer.parseInt(monthlist.get(j))) {

                            if (typelist2.get(j).equals("Expense")) {

                                childName.addLast(childName2.get(j));
                                typeList.addLast(typelist2.get(j));
                                amountList.addLast(amountlist2.get(j));
                                dateList.addLast(datelist2.get(j));
                                categoryList.addLast(categorylist2.get(j));
                                descriptionList.addLast(descriptionlist2.get(j));
                            }

                        }

                    }
                }

                mAdapter=new DataAdapter(getActivity(),typeList,amountList,dateList,categoryList,descriptionList,childName);
                completeRecycle.setLayoutManager(new LinearLayoutManager(getActivity()));
                completeRecycle.setAdapter(mAdapter);

                if (mAdapter.getItemCount()==0){
                    Toast.makeText(getContext(), "No records of expense list!", Toast.LENGTH_SHORT).show();
                }

                swipeController = new SwipeController(new SwipeControllerActions() {
                    @Override
                    public void onRightClicked(final int position) {
                        AlertDialog.Builder adb = new AlertDialog.Builder(getActivity());
                        adb.setMessage("Are you sure you want to delete?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        String[] splitDate=mAdapter.dateList.get(position).split("/");
                                        final String childDate= splitDate[2]+"/"+splitDate[1]+"/"+splitDate[0];

                                        FirebaseDatabase database2=FirebaseDatabase.getInstance();

                                        final DatabaseReference Ref=database2.getReference().child("List");

                                        Ref.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {
                                                Ref.child(childDate).child(mAdapter.childName.get(position)).removeValue();
                                                mAdapter.typeList.remove(position);
                                                mAdapter.amountList.remove(position);
                                                mAdapter.dateList.remove(position);
                                                mAdapter.categoryList.remove(position);
                                                mAdapter.descriptionList.remove(position);
                                                mAdapter.childName.remove(position);
                                                mAdapter.notifyItemRemoved(position);
                                                mAdapter.notifyItemRangeChanged(position, mAdapter.getItemCount());


                                            }

                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });

                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        AlertDialog alert = adb.create();
                        alert.setTitle("Delete List");
                        alert.show();
                    }
                    @Override
                    public void onLeftClicked(final int position) {

                        if (savedInstanceState != null && savedInstanceState.getBoolean("alertShown", true)) {
                            showDialog(getContext(),position);
                            amout.setText(savedInstanceState.getString("Message1"));
                            tvDate.setText(savedInstanceState.getString("Message2"));
                            description.setText(savedInstanceState.getString("Message3"));
                        }

                        showDialog(getContext(),position);

                    }

                });


                ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeController);
                itemTouchhelper.attachToRecyclerView(completeRecycle);

                completeRecycle.addItemDecoration(new RecyclerView.ItemDecoration() {
                    @Override
                    public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                        swipeController.onDraw(c);
                    }
                });

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }

    private DatePickerDialog.OnDateSetListener datePickerListener1 = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String dateYouChoosed = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
            tvDate.setText(dateYouChoosed);


        }
    };

    protected void showDialog(final Context context, final int position) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                context);

        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(getActivity());
        View promptsView = li.inflate(R.layout.prompts, null);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        amout = (EditText) promptsView
                .findViewById(R.id.etAmount);
        amout.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(9, 2)});

        description= promptsView.findViewById(R.id.etDescription);

        mSpCategoryIncome= promptsView.findViewById(R.id.spCategoryIncome);
        mSpCategoryExpense= promptsView.findViewById(R.id.spCategoryExpense);

        mSpCategoryIncome.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        mSpCategoryExpense.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        mSpCategoryExpense.setVisibility(View.GONE);


        mRgType=promptsView.findViewById(R.id.rgType);

        rbId=mRgType.getCheckedRadioButtonId();
        RadioButton rb= promptsView.findViewById(rbId);
        type=rb.getText().toString();

        final RadioButton rbIncome= promptsView.findViewById(R.id.rbIncome);
        final RadioButton rbExpense= promptsView.findViewById(R.id.rbExpense);

        mRgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (rbIncome.isChecked()){
                    mSpCategoryIncome.setVisibility(View.VISIBLE);
                    mSpCategoryExpense.setVisibility(View.GONE);
                    rbId=mRgType.getCheckedRadioButtonId();
                    final RadioButton rb= promptsView.findViewById(rbId);
                    type=rb.getText().toString();
                }else{
                    mSpCategoryIncome.setVisibility(View.GONE);
                    mSpCategoryExpense.setVisibility(View.VISIBLE);
                    rbId=mRgType.getCheckedRadioButtonId();
                    final RadioButton rb= promptsView.findViewById(rbId);
                    type=rb.getText().toString();
                }
            }
        });


        final Button btnDate = (Button) promptsView.findViewById(R.id.btnDate);


        tvDate = (TextView) promptsView.findViewById(R.id.tvDate);

        arrCategory=new ArrayList<String>();
        FirebaseDatabase database=FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("Category").child("Income");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    arrCategory.add(ds.child("categoryName").getValue(String.class));
                }

                ArrayAdapter<String> adCategory= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrCategory);
                adCategory.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mSpCategoryIncome.setAdapter(adCategory);

                int selectionPosition= adCategory.getPosition(mAdapter.categoryList.get(position));
                mSpCategoryIncome.setSelection(selectionPosition);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        arrCategoryExpense=new ArrayList<String>();
        final DatabaseReference myRef2=database.getReference().child("Category").child("Expense");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    arrCategoryExpense.add(ds.child("categoryName").getValue(String.class));

                }

                ArrayAdapter<String> adCategoryExpense= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrCategoryExpense);
                adCategoryExpense.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mSpCategoryExpense.setAdapter(adCategoryExpense);

                int selectionPosition= adCategoryExpense.getPosition(mAdapter.categoryList.get(position));
                mSpCategoryExpense.setSelection(selectionPosition);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        if (mAdapter.typeList.get(position).equals("Income")){
            rbIncome.setChecked(true);
            rbExpense.setChecked(false);
        }else{
            rbIncome.setChecked(false);
            rbExpense.setChecked(true);
        }

        // mSpCategoryIncome.setSelection(((ArrayAdapter<String>)mSpCategoryIncome.getAdapter()).getPosition(mAdapter.categoryList.get(position)));
        //mSpCategoryIncome.setSelection(mAdapter.categoryList.get(position));
        amout.setText(mAdapter.amountList.get(position));
        tvDate.setText(mAdapter.dateList.get(position));
        description.setText(mAdapter.descriptionList.get(position));


        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dateDialog = new DatePickerDialog(getActivity(), datePickerListener1, mYear, mMonth, mDay);
                dateDialog.show();



            }
        });




        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("Save",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {


                                if (TextUtils.isEmpty(amout.getText().toString())) {
                                    Toast.makeText(getActivity(), "Amount cannot be empty", Toast.LENGTH_SHORT).show();

                                } else if (TextUtils.isEmpty(tvDate.getText().toString())) {

                                    Toast.makeText(getActivity(), "Date cannot be empty", Toast.LENGTH_SHORT).show();
                                }else if (Float.parseFloat(amout.getText().toString())==0){

                                    Toast.makeText(getActivity(), "Amount cannot be zero!", Toast.LENGTH_SHORT).show();
                                }  else {

                                    String[] splitDate=mAdapter.dateList.get(position).split("/");
                                    final String childDate= splitDate[2]+"/"+splitDate[1]+"/"+splitDate[0];

                                    FirebaseDatabase database = FirebaseDatabase.getInstance();

                                    final DatabaseReference myRef = database.getReference().child("List");

                                    myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {

                                            String[] splitDate=tvDate.getText().toString().split("/");
                                            String childDate2= splitDate[2]+"/"+splitDate[1]+"/"+splitDate[0];

                                            myRef.child(childDate).child(mAdapter.childName.get(position)).removeValue();
                                            mAdapter.typeList.set(position,type);
                                            mAdapter.amountList.set(position,amout.getText().toString());
                                            mAdapter.dateList.set(position,tvDate.getText().toString());
                                            mAdapter.categoryList.set(position,category);
                                            mAdapter.descriptionList.set(position,description.getText().toString());
                                            mAdapter.childName.set(position,childDate2);
                                            mAdapter.notifyItemRemoved(position);
                                            mAdapter.notifyItemRangeChanged(position, mAdapter.getItemCount());

                                            AccountDetails ad = new AccountDetails(type,amout.getText().toString(),tvDate.getText().toString(),category,
                                                    description.getText().toString());

                                            myRef.child(childDate2).push().setValue(ad);


                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });

                                    //FragmentTransaction transaction = getFragmentManager().beginTransaction();
                                    //transaction.replace(R.id.fragment_container, new Fragment_Tasks()).addToBackStack(null).commit();

                                    Toast.makeText(getActivity(), "Details Saved!", Toast.LENGTH_SHORT).show();

                                }

                            }

                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;
        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }
}