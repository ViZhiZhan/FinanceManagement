package com.example.user.financemanagement;

import android.graphics.Color;
import android.os.Bundle;

import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.Random;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Income_Chart extends Fragment {

    private static String TAG = "MainActivity";
    private float[] yData;
    private String[] xData;
    LinkedList<String> list=new LinkedList<>();
    LinkedList<String> amountlist=new LinkedList<>();
    PieChart pieChart;

    private View data;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        data=inflater.inflate(R.layout.fragment_income_chart,container,false);
        pieChart = (PieChart) data.findViewById(R.id.idPieChart);

        pieChart.setDescription("Monthly type of Income");
        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(25f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("Income Category");
        pieChart.setCenterTextSize(10);


        final String year=String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        final String month=String.valueOf(Calendar.getInstance().get(Calendar.MONTH)+1);

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("List").child(year).child(month);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot datas:dataSnapshot.getChildren()) {

                    for(DataSnapshot ds:datas.getChildren()) {
                        if (ds.child("type").getValue(String.class).equals("Income")) {

                            list.add(ds.child("category").getValue(String.class));
                            amountlist.add(ds.child("amount").getValue(String.class));

                        }
                    }

                }

                int check=0;
                String checkName;
                float checkAmount;

                while(check<list.size()){
                    checkAmount=0;
                    checkName=list.get(check);
                    checkAmount= Float.parseFloat(amountlist.get(check));

                    for (int i=check+1;i<list.size();i++){
                        if (checkName.equals(list.get(i))){

                            checkAmount= checkAmount+ Float.parseFloat(amountlist.get(i));
                            list.remove(i);
                            amountlist.remove(i);
                            amountlist.set(check, String.valueOf(checkAmount));
                            i--;
                        }

                    }


                    check++;

                }

                xData= new String[list.size()];
                yData = new float[amountlist.size()];

                for (int i=0;i<list.size();i++){
                    xData[i]=list.get(i);

                }

                for (int i=0;i<amountlist.size();i++){
                    yData[i]= Float.parseFloat(amountlist.get(i));
                }
                addDataSet();

                pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
                    @Override
                    public void onValueSelected(Entry e, Highlight h) {
                        Log.d(TAG, "onValueSelected: Value select from chart.");
                        Log.d(TAG, "onValueSelected: " + e.toString());
                        Log.d(TAG, "onValueSelected: " + h.toString());

                        int pos1 = e.toString().indexOf("(sum): ");
                        String amount = e.toString().substring(pos1 + 7);

                        for(int i = 0; i < yData.length; i++){
                            if(yData[i] == Float.parseFloat(amount)){
                                pos1 = i;
                                break;
                            }
                        }
                        String type = xData[pos1];
                        String s = String.format("%.2f", Float.parseFloat(amount));
                        Toast.makeText(getContext(), "Income from " + type + "\n" + "Amount: RM" + s, Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onNothingSelected() {

                    }
                });



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        // Inflate the layout for this fragment
        return data;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    private void addDataSet() {
        Log.d(TAG, "addDataSet started");

        ArrayList<Integer> colors = new ArrayList<>();
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "Categories");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);
        Random rnd = new Random();
        //add colors to dataset


        for(int i = 0; i < yData.length; i++){
            yEntrys.add(new PieEntry(yData[i] , i));
        }

        for(int i = 0; i < xData.length; i++){
            xEntrys.add(xData[i]);
            colors.add(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
        }

        pieDataSet.setColors(colors);

        //add legend to chart
        Legend legend = pieChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);

        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();
    }
}
