package com.example.user.financemanagement;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;

import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class SettingActivity extends AppCompatActivity {

    private Button mBtnBlack, mBtnWhite, mBtnGray, mBtnRed, mBtnOrange, mBtnYellow,mBtnGreen,mBtnBlue,mBtnPurple;
    private Button btnCategoryIncome,btnCategoryExpense,btnRemoveIncome,btnRemoveExpense;
    Spinner spRemove;
    private TextView tvIncome,tvExpense;
    private ArrayList<String> name= new ArrayList<>();
    private ArrayList<String> expenseName= new ArrayList<>();
    EditText etCategoryname;
    AlertDialog alert;
    String IncomeName="",ExpenseName="",removeValue="",color;
    ConstraintLayout c1;

    int i=0,j=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        mBtnBlack = (Button) findViewById(R.id.btnBlack);
        mBtnWhite = (Button) findViewById(R.id.btnWhite);
        mBtnGray = (Button) findViewById(R.id.btnGray);
        mBtnRed = (Button) findViewById(R.id.btnRed);
        mBtnOrange = (Button) findViewById(R.id.btnOrange);
        mBtnYellow = (Button) findViewById(R.id.btnYellow);
        mBtnGreen = (Button) findViewById(R.id.btnGreen);
        mBtnBlue = (Button) findViewById(R.id.btnBlue);
        mBtnPurple = (Button) findViewById(R.id.btnPurple);

        btnCategoryIncome= (Button) findViewById(R.id.btnCategoryIncome);
        btnCategoryExpense= (Button) findViewById(R.id.btnCategoryExpense);
        btnRemoveIncome= (Button) findViewById(R.id.btnCategoryIncome2);
        btnRemoveExpense= (Button) findViewById(R.id.btnCategoryExpense2);

        tvIncome= (TextView) findViewById(R.id.tvCategoryIncome2);
        tvExpense = (TextView) findViewById(R.id.tvCategoryExpense2);

        c1= (ConstraintLayout) findViewById(R.id.container);

        FirebaseDatabase database=FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("Category").child("Income");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                    for (DataSnapshot ds : dataSnapshot.getChildren()) {

                            name.add(ds.child("categoryName").getValue(String.class)+"\n");
                    }
                 String Incomename="";
                    for (int i=0;i<name.size();i++){
                        Incomename= Incomename + name.get(i);
                    }
                tvIncome.setMovementMethod(new ScrollingMovementMethod());
                tvIncome.setText(Incomename);


            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        final DatabaseReference myRef2=database.getReference().child("Category").child("Expense");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    expenseName.add(ds.child("categoryName").getValue(String.class)+"\n");
                    //ExpenseName=ExpenseName+ds.child("categoryName").getValue(String.class)+"\n";
                }

                String Expansename="";
                for (int i=0;i<expenseName.size();i++){
                    Expansename= Expansename + expenseName.get(i);
                }

                tvExpense.setMovementMethod(new ScrollingMovementMethod());
                tvExpense.setText(Expansename);
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        final DatabaseReference myRef3 = database.getReference().child("Background");

        myRef3.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot data:dataSnapshot.getChildren()) {
                    color=data.child("code").getValue(String.class);

                    c1.setBackgroundColor(Color.parseColor(color));
                }

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




        btnCategoryIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                LayoutInflater li = LayoutInflater.from(SettingActivity.this);
                View promptsView = li.inflate(R.layout.categoryprompts, null);

                alertDialogBuilder.setView(promptsView);

                etCategoryname= (EditText) promptsView.findViewById(R.id.etCagtegoryName);

                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("Add",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {


                                        if (TextUtils.isEmpty(etCategoryname.getText().toString())) {
                                            Toast.makeText(SettingActivity.this, "Category name cannot be empty", Toast.LENGTH_SHORT).show();

                                        } else {

                                            FirebaseDatabase database = FirebaseDatabase.getInstance();

                                            final DatabaseReference myRef = database.getReference().child("Category");

                                            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {


                                                    Category category= new Category(etCategoryname.getText().toString());

                                                    myRef.child("Income").push().setValue(category);

                                                    name.add(etCategoryname.getText().toString());

                                                    String Incomename="";
                                                    for (int i=0;i<name.size();i++){
                                                        Incomename= Incomename + name.get(i);
                                                    }
                                                    tvIncome.setMovementMethod(new ScrollingMovementMethod());
                                                    tvIncome.setText(Incomename);

                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            });

                                            Toast.makeText(SettingActivity.this, "Category added!", Toast.LENGTH_SHORT).show();

                                        }

                                    }

                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                alert = alertDialogBuilder.create();
                alert.show();

            }
        });

        btnCategoryExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                LayoutInflater li = LayoutInflater.from(SettingActivity.this);
                View promptsView = li.inflate(R.layout.categoryprompts, null);

                alertDialogBuilder.setView(promptsView);

                etCategoryname= (EditText) promptsView.findViewById(R.id.etCagtegoryName);

                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("Add",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {


                                        if (TextUtils.isEmpty(etCategoryname.getText().toString())) {
                                            Toast.makeText(SettingActivity.this, "Category name cannot be empty", Toast.LENGTH_SHORT).show();

                                        } else {

                                            FirebaseDatabase database = FirebaseDatabase.getInstance();

                                            final DatabaseReference myRef = database.getReference().child("Category");

                                            myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                                @Override
                                                public void onDataChange(DataSnapshot dataSnapshot) {


                                                    Category category= new Category(etCategoryname.getText().toString());

                                                    myRef.child("Expense").push().setValue(category);

                                                    expenseName.add(etCategoryname.getText().toString());


                                                    String Expansename="";
                                                    for (int i=0;i<expenseName.size();i++){
                                                        Expansename= Expansename + expenseName.get(i);
                                                    }

                                                    tvExpense.setMovementMethod(new ScrollingMovementMethod());
                                                    tvExpense.setText(Expansename);

                                                }

                                                @Override
                                                public void onCancelled(DatabaseError databaseError) {

                                                }
                                            });

                                            Toast.makeText(SettingActivity.this, "Category added!", Toast.LENGTH_SHORT).show();

                                        }

                                    }

                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                alert = alertDialogBuilder.create();
                alert.show();


            }
        });

        btnRemoveIncome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                LayoutInflater li = LayoutInflater.from(SettingActivity.this);
                View promptsView = li.inflate(R.layout.removeprompts, null);

                alertDialogBuilder.setView(promptsView);

                spRemove = (Spinner) promptsView.findViewById(R.id.spRemove);

                final ArrayList<String> key= new ArrayList<>();
                final ArrayList<String> name2= new ArrayList<>();


                FirebaseDatabase database=FirebaseDatabase.getInstance();

                final DatabaseReference myRef=database.getReference().child("Category").child("Income");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {

                            name2.add(ds.child("categoryName").getValue(String.class));
                            key.add(ds.getKey());
                        }

                        spRemove.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                removeValue = parent.getItemAtPosition(position).toString();
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });


                        ArrayList arrCategory=new ArrayList<String>();
                        for (int counter = 0; counter < name2.size(); counter++) {
                            arrCategory.add(name2.get(counter));
                        }

                        ArrayAdapter<String> adCategory= new ArrayAdapter<>(SettingActivity.this,android.R.layout.simple_spinner_item,arrCategory);
                        adCategory.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spRemove.setAdapter(adCategory);

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("Remove",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        i =0;

                                        FirebaseDatabase database=FirebaseDatabase.getInstance();

                                        final DatabaseReference myRef=database.getReference().child("Category").child("Income");

                                        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {

                                                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                                                    String test=ds.child("categoryName").getValue(String.class);

                                                    if (removeValue.equals(test)) {
                                                        myRef.child(key.get(i)).removeValue();
                                                        name.remove(i);

                                                    }
                                                    i++;
                                                }

                                                String value="";

                                                for (int counter = 0; counter < name.size(); counter++) {
                                                    value= value+name.get(counter);
                                                }
                                                tvIncome.setMovementMethod(new ScrollingMovementMethod());
                                                tvIncome.setText(value);

                                            }
                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });


                                        Toast.makeText(SettingActivity.this, "Removed!", Toast.LENGTH_SHORT).show();

                                    }

                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                alert = alertDialogBuilder.create();
                alert.show();

            }
        });

        btnRemoveExpense.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(v.getContext());

                LayoutInflater li = LayoutInflater.from(SettingActivity.this);
                View promptsView = li.inflate(R.layout.removeprompts, null);

                alertDialogBuilder.setView(promptsView);

                spRemove = (Spinner) promptsView.findViewById(R.id.spRemove);

                final ArrayList<String> key= new ArrayList<>();
                final ArrayList<String> name2= new ArrayList<>();


                FirebaseDatabase database=FirebaseDatabase.getInstance();

                final DatabaseReference myRef=database.getReference().child("Category").child("Expense");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {

                            name2.add(ds.child("categoryName").getValue(String.class));
                            key.add(ds.getKey());
                        }

                        spRemove.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                removeValue = parent.getItemAtPosition(position).toString();
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> parent) {

                            }
                        });


                        ArrayList arrCategory=new ArrayList<String>();
                        for (int counter = 0; counter < name2.size(); counter++) {
                            arrCategory.add(name2.get(counter));
                        }

                        ArrayAdapter<String> adCategory= new ArrayAdapter<>(SettingActivity.this,android.R.layout.simple_spinner_item,arrCategory);
                        adCategory.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spRemove.setAdapter(adCategory);

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });



                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("Remove",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        j=0;

                                        FirebaseDatabase database=FirebaseDatabase.getInstance();

                                        final DatabaseReference myRef3=database.getReference().child("Category").child("Expense");

                                        myRef3.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(DataSnapshot dataSnapshot) {

                                                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                                                    String test=ds.child("categoryName").getValue(String.class);

                                                    if (removeValue.equals(test)) {
                                                        myRef3.child(key.get(j)).removeValue();
                                                        expenseName.remove(j);

                                                    }
                                                    j++;
                                                }

                                                String value="";

                                                for (int counter = 0; counter < expenseName.size(); counter++) {
                                                    value= value+expenseName.get(counter);
                                                }
                                                tvExpense.setMovementMethod(new ScrollingMovementMethod());
                                                tvExpense.setText(value);

                                            }
                                            @Override
                                            public void onCancelled(DatabaseError databaseError) {

                                            }
                                        });


                                        Toast.makeText(SettingActivity.this, "Removed!", Toast.LENGTH_SHORT).show();

                                    }

                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                alert = alertDialogBuilder.create();
                alert.show();

            }
        });



        mBtnBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                       BackgroundColour bc= new BackgroundColour("#000000");

                        myRef.setValue(bc);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


                c1.setBackgroundColor(Color.parseColor("#000000"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });


        mBtnWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#FFFFFF");

                        myRef.setValue(bc);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#FFFFFF"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnGray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#808080");

                        myRef.setValue(bc);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#808080"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#cc0000");

                        myRef.setValue(bc);


                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#cc0000"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnOrange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#ff8800");

                        myRef.setValue(bc);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#ff8800"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#ffee00");

                        myRef.setValue(bc);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#ffee00"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });
        mBtnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#438c57");

                        myRef.setValue(bc);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#438c57"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });
        mBtnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#33b5e5");

                        myRef.setValue(bc);

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#33b5e5"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });
        mBtnPurple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance();

                final DatabaseReference myRef = database.getReference().child("Background").child("colour");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        BackgroundColour bc= new BackgroundColour("#e4b0f7");

                        myRef.setValue(bc);
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
                c1.setBackgroundColor(Color.parseColor("#e4b0f7"));
                Toast.makeText(SettingActivity.this, "Background color has changed!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}