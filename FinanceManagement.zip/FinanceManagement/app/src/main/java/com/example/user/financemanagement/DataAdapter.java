package com.example.user.financemanagement;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class DataAdapter extends RecyclerView.Adapter<DataAdapter.WordViewHolder>{

    public LinkedList<String> typeList;
    public LinkedList<String> amountList;
    public LinkedList<String> dateList;
    public LinkedList<String> categoryList;
    public LinkedList<String> descriptionList;
    public LinkedList<String> childName;
    private LayoutInflater mInflater;
    Context context;

    class WordViewHolder extends  RecyclerView.ViewHolder {
        public final TextView type,amount,date,category,description;
        final DataAdapter mAdapter;

        WordViewHolder (View itemView, DataAdapter adapter){
            super (itemView);

            type=(TextView) itemView.findViewById(R.id.tvTitle);
            amount=(TextView) itemView.findViewById(R.id.tvAmount) ;
            date=(TextView) itemView.findViewById(R.id.tvDate) ;
            category=(TextView) itemView.findViewById(R.id.tvCategory) ;
            description=(TextView) itemView.findViewById(R.id.tvDescription) ;

            mAdapter=adapter;
        }
    }

    DataAdapter (Context context, LinkedList<String> typeList, LinkedList<String> amountList, LinkedList<String> dateList,
                         LinkedList<String> categoryList, LinkedList<String> descriptionList,  LinkedList<String> childName){

        mInflater= LayoutInflater.from((context));
        this.typeList=typeList;
        this.amountList=amountList;
        this.dateList=dateList;
        this.categoryList=categoryList;
        this.descriptionList=descriptionList;
        this.childName=childName;
        this.context=context;

    }

    @NonNull
    @Override
    public DataAdapter.WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View mItemView=mInflater.inflate(R.layout.list_data,parent,false);

        return new WordViewHolder(mItemView,this);
    }

    @Override
    public void onBindViewHolder(@NonNull DataAdapter.WordViewHolder holder, final int position) {

        String mCurrent=typeList.get(position);
        holder.type.setText("Type: "+mCurrent);
        holder.amount.setText("Amount: "+amountList.get(position).toString());
        holder.date.setText("Date: "+dateList.get(position).toString());
        holder.category.setText("Category: "+categoryList.get(position).toString());
        holder.description.setText("Description: "+descriptionList.get(position).toString());

    }

    @Override
    public int getItemCount() {
        return typeList.size();
    }
}