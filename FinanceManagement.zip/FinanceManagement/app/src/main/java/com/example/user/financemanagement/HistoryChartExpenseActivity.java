package com.example.user.financemanagement;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

public class HistoryChartExpenseActivity extends Fragment {

    private static String TAG = "MainActivity";
    private float[] yData;
    private String[] xData;
    LinkedList<String> list=new LinkedList<>();
    LinkedList<String> amountlist=new LinkedList<>();
    final LinkedList<String> monthlist=new LinkedList<>();
    LinkedList<String> list2=new LinkedList<>();
    LinkedList<String> amountlist2=new LinkedList<>();
    LinkedList<String> typelist=new LinkedList<>();

    PieChart pieChart;

    String color,year,month1,month2;
    int month=0;

    ConstraintLayout c1;
    SharedPreferences prf;

    private View data;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        data=inflater.inflate(R.layout.activity_history_chart_expense,container,false);
        pieChart = (PieChart) data.findViewById(R.id.idPieChart);

        c1= (ConstraintLayout)  data.findViewById(R.id.expense2);

        FirebaseDatabase database2 = FirebaseDatabase.getInstance();

        final DatabaseReference myRef2 = database2.getReference().child("Background");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot data:dataSnapshot.getChildren()) {
                    color=data.child("code").getValue(String.class);

                    c1.setBackgroundColor(Color.parseColor(color));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        pieChart.setDescription("Type of Expense");
        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(25f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("Expense Category");
        pieChart.setCenterTextSize(10);


        FirebaseDatabase database=FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("List").child(year);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()){

                    for (DataSnapshot data1 : data.getChildren()) {

                        for (DataSnapshot ds : data1.getChildren()) {
                            if (ds.child("type").getValue(String.class).equals("Expense")) {

                                monthlist.add(data.getKey());
                                typelist.addLast(ds.child("type").getValue(String.class));
                                list2.add(ds.child("category").getValue(String.class));
                                amountlist2.add(ds.child("amount").getValue(String.class));

                            }

                        }

                    }
                }

                for (int i=month; i<=Integer.parseInt(month2);i++){

                    for (int j=0; j<monthlist.size();j++){

                        if (i == Integer.parseInt(monthlist.get(j))) {

                            if (typelist.get(j).equals("Expense")) {

                                list.add(list2.get(j));
                                amountlist.add(amountlist2.get(j));
                            }

                        }

                    }
                }

                int check=0;
                String checkName;
                float checkAmount;

                while(check<list.size()){
                    checkAmount=0;
                    checkName=list.get(check);
                    checkAmount= Float.parseFloat(amountlist.get(check));

                    for (int i=check+1;i<list.size();i++){
                        if (checkName.equals(list.get(i))){

                            checkAmount= checkAmount+ Float.parseFloat(amountlist.get(i));
                            list.remove(i);
                            amountlist.remove(i);
                            amountlist.set(check, String.valueOf(checkAmount));
                            i--;

                        }
                    }

                    check++;
                }

                xData= new String[list.size()];
                yData = new float[amountlist.size()];

                for (int i=0;i<list.size();i++){
                    xData[i]=list.get(i);

                }

                for (int i=0;i<amountlist.size();i++){
                    yData[i]= Float.parseFloat(amountlist.get(i));
                }
                addDataSet();

                pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
                    @Override
                    public void onValueSelected(Entry e, Highlight h) {
                        Log.d(TAG, "onValueSelected: Value select from chart.");
                        Log.d(TAG, "onValueSelected: " + e.toString());
                        Log.d(TAG, "onValueSelected: " + h.toString());

                        int pos1 = e.toString().indexOf("(sum): ");
                        String amount = e.toString().substring(pos1 + 7);

                        for(int i = 0; i < yData.length; i++){
                            if(yData[i] == Float.parseFloat(amount)){
                                pos1 = i;
                                break;
                            }
                        }
                        String type = xData[pos1];
                        String s = String.format("%.2f", Float.parseFloat(amount));
                        Toast.makeText(getContext(), "Expense from " + type + "\n" + "Amount: RM" + s, Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onNothingSelected() {

                    }
                });



            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        // Inflate the layout for this fragment
        return data;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prf = getContext().getSharedPreferences("history", Context.MODE_PRIVATE);

        year = prf.getString("year",null);
        month1 = prf.getString("month1",null);
        month2 = prf.getString("month2",null);

        month=Integer.parseInt(month1);

    }
    private void addDataSet() {
        Log.d(TAG, "addDataSet started");

        ArrayList<Integer> colors = new ArrayList<>();
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        //create the data set
        PieDataSet pieDataSet = new PieDataSet(yEntrys, "Categories");
        pieDataSet.setSliceSpace(2);
        pieDataSet.setValueTextSize(12);
        Random rnd = new Random();
        //add colors to dataset


        for(int i = 0; i < yData.length; i++){
            yEntrys.add(new PieEntry(yData[i] , i));
        }

        for(int i = 0; i < xData.length; i++){
            xEntrys.add(xData[i]);
            colors.add(Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256)));
        }

        pieDataSet.setColors(colors);

        //add legend to chart
        Legend legend = pieChart.getLegend();
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setPosition(Legend.LegendPosition.LEFT_OF_CHART);

        //create pie data object
        PieData pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieChart.invalidate();
    }
}