package com.example.user.financemanagement;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import static android.content.Context.MODE_PRIVATE;

public class Fragment_Profile extends Fragment {

    private RecyclerView mRecyclerView;
    private ArrayList<Data> mData;
    private DataAdapter mAdapter;
    private TextView tvIncome,tvExpense,tvTotalIncome,tvTotalExpense,tvCashFlow;
    private Button btnHistory;
    ArrayList<String> arrYear,arrMonth1,arrMonth2;
    Spinner spYear,spMonth1,spMonth2;
    AlertDialog alert;
    String selectedYear,selectedMonth1,selectedMonth2;

    float totalIncome=0,totalExpense=0,cashFlow=0;
    int LAUNCH_SECOND_ACTIVITY = 1;
    SharedPreferences prf;

    @RequiresApi(api = Build.VERSION_CODES.P)

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        tvIncome= (TextView) view.findViewById(R.id.tvCategoryIncome2);
        tvExpense= (TextView) view.findViewById(R.id.tvCategoryExpense2);
        tvTotalIncome= (TextView) view.findViewById(R.id.tvTotalIncome2);
        tvTotalExpense= (TextView) view.findViewById(R.id.tvTotalExpense2);
        tvCashFlow= (TextView) view.findViewById(R.id.tvBalance);
        btnHistory= (Button) view.findViewById(R.id.btnHistory);

        final String year=String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        final String month=String.valueOf(Calendar.getInstance().get(Calendar.MONTH)+1);

        final LinkedList<String> list=new LinkedList<>();
        final LinkedList<String> incomelist=new LinkedList<>();
        final Set set = new LinkedHashSet();
        final Set incomeset = new LinkedHashSet();

        prf = getContext().getSharedPreferences("history",MODE_PRIVATE);

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("List").child(year).child(month);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot datas:dataSnapshot.getChildren()) {

                    for(DataSnapshot ds:datas.getChildren()) {
                        if (ds.child("type").getValue(String.class).equals("Income")) {
                            totalIncome= totalIncome+ Float.parseFloat(ds.child("amount").getValue(String.class));
                            incomeset.add(ds.child("category").getValue(String.class));

                        }else{
                           totalExpense = totalExpense+ Float.parseFloat(ds.child("amount").getValue(String.class));
                           set.add(ds.child("category").getValue(String.class));
                        }
                    }

                }

               // LinkedHashSet<String> hashSet=new LinkedHashSet<>(list);

                list.clear();
                list.addAll(set);

                incomelist.clear();
                incomelist.addAll(incomeset);

                String expense="";
                for (int i=0;i<list.size();i++){
                    expense= expense+list.get(i)+"\n";
                }

                String income="";
                for (int i=0;i<incomelist.size();i++){
                    income= income+incomelist.get(i)+"\n";
                }

                tvIncome.setMovementMethod(new ScrollingMovementMethod());
                tvExpense.setMovementMethod(new ScrollingMovementMethod());
                tvExpense.setText(expense);
                tvIncome.setText(income);

                String s1 = String.format("%.2f", totalIncome);
                String s2 = String.format("%.2f", totalExpense);

                tvTotalIncome.setText("RM"+s1);
                tvTotalExpense.setText("RM" + s2);
               cashFlow=totalIncome-totalExpense;
                String s = String.format("%.2f", cashFlow);
               tvCashFlow.setText("Cash Flow: RM "+s);

               if (cashFlow<0){
               tvCashFlow.setBackgroundColor(Color.parseColor("#E87567"));
               }else{
                   tvCashFlow.setBackgroundColor(Color.parseColor("#C9F994"));
               }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                        getContext());

                // get prompts.xml view
                LayoutInflater li = LayoutInflater.from(getActivity());
                final View promptsView = li.inflate(R.layout.historyprompt, null);

                spYear = (Spinner) promptsView.findViewById(R.id.spYear);
                spMonth1 = (Spinner) promptsView.findViewById(R.id.spMonth1);
                spMonth2 = (Spinner) promptsView.findViewById(R.id.spMonth2);

                arrYear=new ArrayList<String>();
                arrMonth1=new ArrayList<String>();
                arrMonth2=new ArrayList<String>();

                FirebaseDatabase database=FirebaseDatabase.getInstance();

                final DatabaseReference myRef=database.getReference().child("List");

                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            arrYear.add(ds.getKey());

                        }

                        for (int i=1;i<=12;i++){
                            arrMonth1.add(String.valueOf(i));
                            arrMonth2.add(String.valueOf(i));
                        }

                        ArrayAdapter<String> adYear= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrYear);
                        adYear.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spYear.setAdapter(adYear);

                        ArrayAdapter<String> adMonth1= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrMonth1);
                        adMonth1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spMonth1.setAdapter(adMonth1);

                        ArrayAdapter<String> adMonth2= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrMonth2);
                        adMonth2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spMonth2.setAdapter(adMonth2);

                    }
                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

                spYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selectedYear = parent.getItemAtPosition(position).toString();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

                spMonth1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selectedMonth1 = parent.getItemAtPosition(position).toString();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

                spMonth2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        selectedMonth2 = parent.getItemAtPosition(position).toString();
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

                // set historyprompts.xml to alertdialog builder
                alertDialogBuilder.setView(promptsView);

                // set dialog message
                alertDialogBuilder
                        .setCancelable(false)
                        .setPositiveButton("Go",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        if (Integer.parseInt(selectedMonth1)>Integer.parseInt(selectedMonth2)){
                                            Toast.makeText(getContext(), "Please select proper range between two month", Toast.LENGTH_SHORT).show();
                                        }else{

                                            SharedPreferences.Editor editor = prf.edit();
                                            editor.putString("year",selectedYear);
                                            editor.putString("month1",selectedMonth1);
                                            editor.putString("month2",selectedMonth2);
                                            editor.commit();


                                            Intent i = new Intent(getActivity(),HistoryActivity.class);
                                            startActivity(i);

                                        }



                                    }

                                })
                        .setNegativeButton("Cancel",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        dialog.cancel();
                                    }
                                });

                alert = alertDialogBuilder.create();
                alert.show();

            }
        });


        return view;
    }



}
