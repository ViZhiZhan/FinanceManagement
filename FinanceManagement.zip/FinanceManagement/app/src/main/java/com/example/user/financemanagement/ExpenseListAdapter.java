package com.example.user.financemanagement;

import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ExpenseListAdapter extends RecyclerView.Adapter<ExpenseListAdapter.ViewHolder> {

    //Member variables
    private ArrayList<ExpenseList> mData;
    private Context mContext;

    ExpenseListAdapter(Context context, ArrayList<ExpenseList> data) {
        this.mData = data;
        this.mContext = context;
    }

    @NonNull
    @Override
    public ExpenseListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
        return new ViewHolder(LayoutInflater.from(mContext).inflate(R.layout.list_expense, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ExpenseListAdapter.ViewHolder holder, int position) {
        //Get current sport
        ExpenseList currentSport = mData.get(position);
        //Populate the textviews with data
        holder.bindTo(currentSport);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        //Member Variables for the TextViews
        private TextView mTitleText;
        private TextView mAmountText;

        /**
         * Constructor for the ViewHolder, used in onCreateViewHolder().
         * @param itemView The rootview of the list_item.xml layout file
         */
        ViewHolder(View itemView) {
            super(itemView);

            //Initialize the views
            mTitleText = (TextView)itemView.findViewById(R.id.tvTitle);
            mAmountText = (TextView)itemView.findViewById(R.id.tvAmount);

        }

        void bindTo(ExpenseList currentSport){
            //Populate the textviews with data
            mTitleText.setText(currentSport.getTitle());
            mAmountText.setText(currentSport.getAmount());

        }
    }
}
