package com.example.user.financemanagement;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;

import android.os.Bundle;

import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Set;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class HistorySummaryActivity extends AppCompatActivity {

    private TextView tvIncome,tvExpense,tvTotalIncome,tvTotalExpense,tvCashFlow;

    float totalIncome=0,totalExpense=0,cashFlow=0;

    String color,year,month1,month2;

    int month=0;
    ConstraintLayout c1;
    SharedPreferences prf;

    @RequiresApi(api = Build.VERSION_CODES.P)

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_summary);

        tvIncome= (TextView) findViewById(R.id.tvCategoryIncome2);
        tvExpense= (TextView) findViewById(R.id.tvCategoryExpense2);
        tvTotalIncome= (TextView) findViewById(R.id.tvTotalIncome2);
        tvTotalExpense= (TextView) findViewById(R.id.tvTotalExpense2);
        tvCashFlow= (TextView) findViewById(R.id.tvBalance);
        c1= (ConstraintLayout) findViewById(R.id.container);

        prf = getSharedPreferences("history", Context.MODE_PRIVATE);

        year = prf.getString("year",null);
        month1 = prf.getString("month1",null);
        month2 = prf.getString("month2",null);

        month=Integer.parseInt(month1);

       // Toast.makeText(this, year + month1+ month2, Toast.LENGTH_SHORT).show();

        final LinkedList<String> list=new LinkedList<>();
        final LinkedList<String> incomelist=new LinkedList<>();
        final LinkedList<String> monthlist=new LinkedList<>();
        final LinkedList<String> categorylist=new LinkedList<>();
        final LinkedList<String> amountlist=new LinkedList<>();
        final LinkedList<String> typelist=new LinkedList<>();
        final Set set = new LinkedHashSet();
        final Set incomeset = new LinkedHashSet();

        FirebaseDatabase database2 = FirebaseDatabase.getInstance();

        final DatabaseReference myRef2 = database2.getReference().child("Background");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for(DataSnapshot data:dataSnapshot.getChildren()) {
                    color=data.child("code").getValue(String.class);

                    c1.setBackgroundColor(Color.parseColor(color));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        FirebaseDatabase database = FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("List").child(year);

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot data : dataSnapshot.getChildren()){

                        for (DataSnapshot data1 : data.getChildren()) {

                                for (DataSnapshot ds : data1.getChildren()) {
                                    if (ds.child("type").getValue(String.class).equals("Income")) {
                                       // totalIncome = totalIncome + Float.parseFloat(ds.child("amount").getValue(String.class));
                                       // incomeset.add(ds.child("category").getValue(String.class));
                                        monthlist.add(data.getKey());
                                        categorylist.add(ds.child("category").getValue(String.class));
                                        amountlist.add(ds.child("amount").getValue(String.class));
                                        typelist.add(ds.child("type").getValue(String.class));

                                    } else {
                                       // totalExpense = totalExpense + Float.parseFloat(ds.child("amount").getValue(String.class));
                                       // set.add(ds.child("category").getValue(String.class));
                                        monthlist.add(data.getKey());
                                        categorylist.add(ds.child("category").getValue(String.class));
                                        amountlist.add(ds.child("amount").getValue(String.class));
                                        typelist.add(ds.child("type").getValue(String.class));
                                    }
                                }

                        }
            }
                // LinkedHashSet<String> hashSet=new LinkedHashSet<>(list);


                for (int i=month; i<=Integer.parseInt(month2);i++){

                    for (int j=0; j<monthlist.size();j++){

                    if (i == Integer.parseInt(monthlist.get(j))) {

                            if (typelist.get(j).equals("Income")) {
                                totalIncome = totalIncome + Float.parseFloat(amountlist.get(j));
                                incomeset.add(categorylist.get(j));

                            } else {
                                totalExpense = totalExpense + Float.parseFloat(amountlist.get(j));
                                set.add(categorylist.get(j));

                            }

                    }

                    }
                }

                list.clear();
                list.addAll(set);

                incomelist.clear();
                incomelist.addAll(incomeset);

                String expense="";
                for (int i=0;i<list.size();i++){
                    expense= expense+list.get(i)+"\n";
                }

                String income="";
                for (int i=0;i<incomelist.size();i++){
                    income= income+incomelist.get(i)+"\n";
                }

                tvIncome.setMovementMethod(new ScrollingMovementMethod());
                tvExpense.setMovementMethod(new ScrollingMovementMethod());
                tvExpense.setText(expense);
                tvIncome.setText(income);

                if (TextUtils.isEmpty(tvIncome.getText().toString())){
                    tvIncome.setMovementMethod(new ScrollingMovementMethod());
                    tvIncome.setText("No record");
                }

                if (TextUtils.isEmpty(tvExpense.getText().toString())){
                    tvExpense.setMovementMethod(new ScrollingMovementMethod());
                    tvExpense.setText("No record");
                }

                String s1 = String.format("%.2f", totalIncome);
                String s2 = String.format("%.2f", totalExpense);

                tvTotalIncome.setText("RM"+s1);
                tvTotalExpense.setText("RM" + s2);
                cashFlow=totalIncome-totalExpense;
                String s = String.format("%.2f", cashFlow);
                tvCashFlow.setText("Cash Flow: RM "+s);

                if (cashFlow<0){
                    tvCashFlow.setBackgroundColor(Color.parseColor("#E87567"));
                }else{
                    tvCashFlow.setBackgroundColor(Color.parseColor("#C9F994"));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}