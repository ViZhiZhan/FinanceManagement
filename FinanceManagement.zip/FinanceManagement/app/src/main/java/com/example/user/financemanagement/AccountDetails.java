package com.example.user.financemanagement;

public class AccountDetails {

    public String type;
    public String amount;
    public String date;
    public String category;
    public String description;

    public AccountDetails(){

    }

    public AccountDetails(String type, String amount, String date, String category, String description) {
        this.type = type;
        this.amount = amount;
        this.date = date;
        this.category = category;
        this.description = description;
    }
}
