package com.example.user.financemanagement;

public class Data {

    //Member variables representing the title and information about the sport
    private String title;
    private String amount;
    private String date;
    private String category;
    private String description;


    /**
     * Constructor for the Data data model
     * @param title The title of the data.
     * @param amount amount about the data.
     */
    Data(String title, String amount, String date, String category, String description) {
        this.title = title;
        this.amount = amount;
        this.date=date;
        this.category=category;
        this.description=description;
    }

    /**
     * Gets the title of the data
     * @return The title of the data.
     */
    String getTitle() {
        return title;
    }
    /**
     * Gets the amount about the data
     * @return The info about the data.
     */
    String getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getCategory() {
        return category;
    }

    public String getDescription() {
        return description;
    }
}
