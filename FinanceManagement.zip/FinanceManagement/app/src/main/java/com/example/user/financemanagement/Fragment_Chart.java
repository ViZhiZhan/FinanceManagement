package com.example.user.financemanagement;

import android.graphics.Color;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;

public class Fragment_Chart extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_chart, container, false);

        final TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Income"));
        tabLayout.addTab(tabLayout.newTab().setText("Expense"));


        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager vp = (ViewPager) view.findViewById(R.id.viewPager);

        final PagerAdapter2 pa = new com.example.user.financemanagement.PagerAdapter2(((AppCompatActivity) getActivity()).getSupportFragmentManager(), tabLayout.getTabCount());

        vp.setAdapter(pa);

        vp.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vp.setCurrentItem(tab.getPosition());

                if (tab.getPosition() == 0) {
                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#ff99cc00"));

                    //FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //  ft.remove((Fragment)Fragment_Tasks.this).commitNowAllowingStateLoss();
                    // ft.detach(Fragment_Tasks.this).attach(Fragment_Tasks.this).commit();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragment_container, new Fragment_Chart()).addToBackStack(null);
                    transaction.commit();


                } else if (tab.getPosition() == 1) {

                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#FF1700"));


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });//*/

        return view;
    }
}
