package com.example.user.financemanagement;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;

import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.viewpager.widget.ViewPager;


public class Fragment_Home extends Fragment {

    boolean click;
    EditText amout,description;
    TextView tvDate;
    AlertDialog alert;
    Spinner mSpCategoryIncome,mSpCategoryExpense;
    ArrayList<String> arrCategory,arrCategoryExpense;
    RadioGroup mRgType;
    String type,category;
    int rbId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        FloatingActionButton fab = (FloatingActionButton) view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                click=true;
                showDialog(view.getContext());
            }
        });


        final TabLayout tabLayout = (TabLayout) view.findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Income"));
        tabLayout.addTab(tabLayout.newTab().setText("Expense"));


        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final ViewPager vp = (ViewPager) view.findViewById(R.id.viewPager);

        final PagerAdapter pa = new com.example.user.financemanagement.PagerAdapter(((AppCompatActivity) getActivity()).getSupportFragmentManager(), tabLayout.getTabCount());

        vp.setAdapter(pa);

        vp.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                vp.setCurrentItem(tab.getPosition());

                if (tab.getPosition() == 0) {
                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#ff99cc00"));

                    //FragmentTransaction ft = getFragmentManager().beginTransaction();
                    //  ft.remove((Fragment)Fragment_Tasks.this).commitNowAllowingStateLoss();
                    // ft.detach(Fragment_Tasks.this).attach(Fragment_Tasks.this).commit();
                    FragmentTransaction transaction = getFragmentManager().beginTransaction();
                    transaction.replace(R.id.fragment_container, new Fragment_Home()).addToBackStack(null);
                    transaction.commit();


                } else if (tab.getPosition() == 1) {

                    tabLayout.setTabTextColors(Color.parseColor("#ffaa66cc"), Color.parseColor("#FF1700"));


                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });//*/

        return view;
    }

    private DatePickerDialog.OnDateSetListener datePickerListener1 = new DatePickerDialog.OnDateSetListener() {

        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String dateYouChoosed = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
            tvDate.setText(dateYouChoosed);


        }
    };



    // put all creating dialog stuff in a single method
    protected void showDialog(final Context context) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                context);

        // get prompts.xml view
        LayoutInflater li = LayoutInflater.from(getActivity());
        final View promptsView = li.inflate(R.layout.prompts, null);

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        amout = (EditText) promptsView
                .findViewById(R.id.etAmount);
        amout.setFilters(new InputFilter[]{new DecimalDigitsInputFilter(9, 2)});

        description= promptsView.findViewById(R.id.etDescription);

        mSpCategoryIncome= promptsView.findViewById(R.id.spCategoryIncome);
        mSpCategoryExpense= promptsView.findViewById(R.id.spCategoryExpense);

        mSpCategoryIncome.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        mSpCategoryExpense.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                category = parent.getItemAtPosition(position).toString();
            }
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        mSpCategoryExpense.setVisibility(View.GONE);


        mRgType=promptsView.findViewById(R.id.rgType);
        rbId=mRgType.getCheckedRadioButtonId();
        final RadioButton rb= promptsView.findViewById(rbId);
        type=rb.getText().toString();


        final RadioButton rbIncome= promptsView.findViewById(R.id.rbIncome);

        mRgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (rbIncome.isChecked()){
                    mSpCategoryIncome.setVisibility(View.VISIBLE);
                    mSpCategoryExpense.setVisibility(View.GONE);
                    rbId=mRgType.getCheckedRadioButtonId();
                    final RadioButton rb= promptsView.findViewById(rbId);
                    type=rb.getText().toString();
                }else{
                    mSpCategoryIncome.setVisibility(View.GONE);
                    mSpCategoryExpense.setVisibility(View.VISIBLE);
                    rbId=mRgType.getCheckedRadioButtonId();
                    final RadioButton rb= promptsView.findViewById(rbId);
                    type=rb.getText().toString();
                }
            }
        });


        final Button btnDate = (Button) promptsView.findViewById(R.id.btnDate);


        tvDate = (TextView) promptsView.findViewById(R.id.tvDate);

        arrCategory=new ArrayList<String>();

        FirebaseDatabase database=FirebaseDatabase.getInstance();

        final DatabaseReference myRef=database.getReference().child("Category").child("Income");

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    arrCategory.add(ds.child("categoryName").getValue(String.class));
                }

                ArrayAdapter<String> adCategory= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrCategory);
                adCategory.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mSpCategoryIncome.setAdapter(adCategory);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        arrCategoryExpense=new ArrayList<String>();

        final DatabaseReference myRef2=database.getReference().child("Category").child("Expense");

        myRef2.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    arrCategoryExpense.add(ds.child("categoryName").getValue(String.class));

                }

                ArrayAdapter<String> adCategoryExpense= new ArrayAdapter<>(getActivity(),android.R.layout.simple_spinner_item,arrCategoryExpense);
                adCategoryExpense.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                mSpCategoryExpense.setAdapter(adCategoryExpense);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



        btnDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR);
                int mMonth = c.get(Calendar.MONTH);
                int mDay = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog dateDialog = new DatePickerDialog(getActivity(), datePickerListener1, mYear, mMonth, mDay);
                dateDialog.show();



            }
        });




        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("Add",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {


                                if (TextUtils.isEmpty(amout.getText().toString())) {
                                    Toast.makeText(getActivity(), "Amount cannot be empty", Toast.LENGTH_SHORT).show();

                                } else if (TextUtils.isEmpty(tvDate.getText().toString())) {

                                    Toast.makeText(getActivity(), "Date cannot be empty", Toast.LENGTH_SHORT).show();
                                }else if (Float.parseFloat(amout.getText().toString())==0){

                                    Toast.makeText(getActivity(), "Amount cannot be zero!", Toast.LENGTH_SHORT).show();
                                }
                                else {

                                    FirebaseDatabase database = FirebaseDatabase.getInstance();

                                    final DatabaseReference myRef = database.getReference().child("List");

                                    myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {


                                            AccountDetails ad = new AccountDetails(type,amout.getText().toString(),tvDate.getText().toString(),category,
                                                    description.getText().toString());

                                            String[] splitDate=tvDate.getText().toString().split("/");
                                            String childDate= splitDate[2]+"/"+splitDate[1]+"/"+splitDate[0];

                                            myRef.child(childDate).push().setValue(ad);

                                            FragmentTransaction transaction = getFragmentManager().beginTransaction();
                                            transaction.replace(R.id.fragment_container, new Fragment_Home()).addToBackStack(null);
                                            transaction.commit();
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError databaseError) {

                                        }
                                    });

                                    //FragmentTransaction transaction = getFragmentManager().beginTransaction();
                                    //transaction.replace(R.id.fragment_container, new Fragment_Tasks()).addToBackStack(null).commit();

                                    Toast.makeText(getActivity(), "List added!", Toast.LENGTH_SHORT).show();

                                }

                            }

                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        alert = alertDialogBuilder.create();
        alert.show();
    }

    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;
        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }

}
